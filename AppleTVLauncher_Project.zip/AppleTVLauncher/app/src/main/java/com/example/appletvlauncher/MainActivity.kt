package com.example.appletvlauncher

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class TvApp(
    val label: String,
    val packageName: String,
    val icon: Drawable,
    val banner: Drawable?
)

class MainActivity : AppCompatActivity() {
    private lateinit var grid: RecyclerView
    private lateinit var dock: RecyclerView
    private lateinit var apps: List<TvApp>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<TextView>(R.id.clock).apply {
            format12Hour = "h:mm a"
            format24Hour = "HH:mm"
        }
        findViewById<ImageButton>(R.id.settingsButton).setOnClickListener {
            runCatching {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            }.onFailure {
                Toast.makeText(this, R.string.settings_unavailable, Toast.LENGTH_SHORT).show()
            }
        }

        apps = loadApps()
        grid = findViewById(R.id.appGrid)
        dock = findViewById(R.id.dock)

        dock.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        dock.adapter = AppAdapter(apps.take(8), isDock = true) { launch(it) }

        grid.layoutManager = GridLayoutManager(this, 5)
        grid.adapter = AppAdapter(apps, isDock = false) { launch(it) }

        if (apps.isEmpty()) {
            Toast.makeText(this, R.string.no_apps, Toast.LENGTH_LONG).show()
        } else {
            grid.post { grid.getChildAt(0)?.requestFocus() }
        }
    }

    @Suppress("DEPRECATION")
    private fun loadApps(): List<TvApp> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val leanbackIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val resolved = (pm.queryIntentActivities(intent, 0) +
                pm.queryIntentActivities(leanbackIntent, 0))
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != packageName }

        return resolved.mapNotNull { info ->
            runCatching {
                val ai = info.activityInfo.applicationInfo
                TvApp(
                    label = info.loadLabel(pm).toString(),
                    packageName = info.activityInfo.packageName,
                    icon = info.loadIcon(pm),
                    banner = (if (info.activityInfo.banner != 0) {
                        pm.getDrawable(info.activityInfo.packageName, info.activityInfo.banner, ai)
                    } else if (ai.banner != 0) {
                        pm.getDrawable(info.activityInfo.packageName, ai.banner, ai)
                    } else null)
                )
            }.getOrNull()
        }.sortedBy { it.label.lowercase() }
    }

    private fun launch(app: TvApp) {
        val launchIntent = packageManager.getLaunchIntentForPackage(app.packageName)
        if (launchIntent != null) {
            runCatching { startActivity(launchIntent) }
                .onFailure { Toast.makeText(this, R.string.cannot_launch, Toast.LENGTH_SHORT).show() }
        } else {
            Toast.makeText(this, R.string.no_launch_activity, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        // Keep this activity as the home surface; Back does not close the launcher.
        // The system may still handle HOME or power-related navigation keys.
    }
}

private class AppAdapter(
    private val items: List<TvApp>,
    private val isDock: Boolean,
    private val onClick: (TvApp) -> Unit
) : RecyclerView.Adapter<AppAdapter.AppViewHolder>() {

    class AppViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: android.widget.ImageView = view.findViewById(R.id.appImage)
        val label: TextView = view.findViewById(R.id.appLabel)
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): AppViewHolder {
        val layout = if (isDock) R.layout.item_dock else R.layout.item_app
        val view = android.view.LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val app = items[position]
        holder.label.text = app.label
        holder.image.setImageDrawable(if (!isDock && app.banner != null) app.banner else app.icon)
        holder.itemView.contentDescription = app.label
        holder.itemView.isFocusable = true
        holder.itemView.isFocusableInTouchMode = true
        holder.itemView.setOnClickListener { onClick(app) }
        holder.itemView.setOnFocusChangeListener { view, focused ->
            val scale = if (focused) 1.16f else 1f
            view.animate().scaleX(scale).scaleY(scale)
                .translationZ(if (focused) 14f else 0f)
                .setDuration(180).start()
            view.elevation = if (focused) 18f else 2f
            holder.label.setTextColor(if (focused) Color.WHITE else Color.rgb(190, 196, 210))
            holder.label.alpha = if (focused) 1f else 0.82f
        }
    }

    override fun getItemCount(): Int = items.size
}
